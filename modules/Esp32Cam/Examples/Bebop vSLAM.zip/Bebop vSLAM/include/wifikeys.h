// wifi authentication
// const char *ssid =     "ssid";
// const char *password = "spass";

const char* ssid = "NERO";
const char* password = "BDPsystem10";
